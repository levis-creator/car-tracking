package com.example.cartracking;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class PlaceHolder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_holder);
    }
}