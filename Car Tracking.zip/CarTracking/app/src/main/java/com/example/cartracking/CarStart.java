package com.example.cartracking;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CarStart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_start);
        Button startCar= findViewById(R.id.startCar);
        startCar.setOnClickListener(view -> Toast.makeText(getApplicationContext(),"Please wait...",Toast.LENGTH_LONG).show());

    }
}